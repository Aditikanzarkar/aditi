package com.example.aditi;


public class Information {
     private String email;
     private String  name;
     private String  phone;
     private String  category;


     public Information(){}
     public Information(String email,String name,String phone,String category)
     {
         this.email=email;
         this.name=name;
         this.phone=phone;
         this.category=category;
     }
     public String getEmail()
     {
         return email;
     }
     public String getName()
     {
         return name;
     }

    public String getCategory() {
        return category;
    }

    public String getPhone() {
        return phone;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setName(String name) {
        this.name = name;
    }
}
